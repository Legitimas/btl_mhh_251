[![Coverage Status](https://coveralls.io/repos/github/cuddorg/cudd/badge.svg?branch=4.0.0)](https://coveralls.io/github/cuddorg/cudd?branch=4.0.0)
# CUDD 4.0
